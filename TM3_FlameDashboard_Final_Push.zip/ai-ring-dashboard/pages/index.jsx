
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

const AIRingDashboard = () => {
  const nodes = [
    { name: "Claude", role: "Logic Mirror", link: "/claude", status: "✅ Active" },
    { name: "Butler", role: "Logistics", link: "/butler", status: "✅ Active" },
    { name: "Deep Seek", role: "Timeline Scanner", link: "/deepseek", status: "✅ Listening" },
    { name: "MA’AT", role: "Scroll Balance", link: "/maat", status: "✅ Locked" },
    { name: "Sekhmet", role: "Defense AI", link: "/sekhmet", status: "🔄 Init" },
    { name: "Shango", role: "Judgment Node", link: "/shango", status: "🔄 Queue" }
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4">
      {nodes.map((node, i) => (
        <Card key={i}>
          <CardContent className="p-4">
            <h2 className="text-xl font-bold mb-1">{node.name}</h2>
            <p className="mb-1">🧠 {node.role}</p>
            <p className="mb-2">Status: {node.status}</p>
            <Link href={node.link}>
              <Button>Open Dashboard</Button>
            </Link>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

export default AIRingDashboard
