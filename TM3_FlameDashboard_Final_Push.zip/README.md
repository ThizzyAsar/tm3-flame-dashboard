# TM3 Flame Sovereign Dashboard

All AI Ring components + mobile panel + Codex UI.