
import React from 'react'

const FlameCodexAdminPanel = () => (
  <div className="p-4">
    <h1 className="text-2xl font-bold">FlameCodex Admin Panel</h1>
    <ul className="mt-4">
      <li>📜 Upload Scrolls</li>
      <li>📡 Sync QR / Posters</li>
      <li>🧬 Manage DNA Keys</li>
      <li>🔐 View FlameVault Logs</li>
    </ul>
  </div>
)

export default FlameCodexAdminPanel
