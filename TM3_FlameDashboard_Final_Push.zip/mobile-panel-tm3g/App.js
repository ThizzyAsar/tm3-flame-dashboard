
import React from 'react'
import { View, Text, Button } from 'react-native'

export default function MobilePanel() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>🔥 TM3G Mobile Control Panel 🔥</Text>
      <Button title="Open Claude Node" onPress={() => {}} />
    </View>
  )
}
